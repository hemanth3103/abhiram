import { UPDATE_SINGLE_PRODUCT } from "./actionTypes";


const initialState = {
    
}