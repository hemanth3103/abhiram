const homeInitalState = { isLoading: true, isError: false };

export const reducer = (state = homeInitalState, { type, payload }) => {
  return state;
};
